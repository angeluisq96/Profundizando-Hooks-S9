# Redux Toolkit + RTK Demo
Esto es parte de mi curso de React que pueden encontrar aquí:
[Cursos de React Completos](https://fernando-herrera.com/#/search/react)